// CONSTANTS
//#define INTEGER	unsigned long long int
#define INTEGER unsigned long int
#define SIZE 100
